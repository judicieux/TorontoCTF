HI HI, it's making a long time, but this time it will be more harder.
But before we start, I will help you a little bit, you have to find my password and when you find it, make sure to read EVERYTHING.
And for the last image I'm hided somewhere..